#ifndef __AUTODRIVE_H__
#define	__AUTODRIVE_H__

void steer(float steera);
void rearspeed(float speed);
void frontspeed(float speed);
void mecanum_basic(float y,float w);
#endif