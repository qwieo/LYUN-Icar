/*********************************************************************************************************************
* RT1064DVL6A Opensourec Library ����RT1064DVL6A ��Դ�⣩��һ�����ڹٷ� SDK �ӿڵĵ�������Դ��
* Copyright (c) 2022 SEEKFREE ��ɿƼ�
* 
* ���ļ��� RT1064DVL6A ��Դ���һ����
* 
* RT1064DVL6A ��Դ�� ���������
* �����Ը���������������ᷢ���� GPL��GNU General Public License���� GNUͨ�ù�������֤��������
* �� GPL �ĵ�3�棨�� GPL3.0������ѡ��ģ��κκ����İ汾�����·�����/���޸���
* 
* ����Դ��ķ�����ϣ�����ܷ������ã�����δ�������κεı�֤
* ����û�������������Ի��ʺ��ض���;�ı�֤
* ����ϸ����μ� GPL
* 
* ��Ӧ�����յ�����Դ���ͬʱ�յ�һ�� GPL �ĸ���
* ���û�У������<https://www.gnu.org/licenses/>
* 
* ����ע����
* ����Դ��ʹ�� GPL3.0 ��Դ����֤Э�� ������������Ϊ���İ汾
* ��������Ӣ�İ��� libraries/doc �ļ����µ� GPL3_permission_statement.txt �ļ���
* ����֤������ libraries �ļ����� �����ļ����µ� LICENSE �ļ�
* ��ӭ��λʹ�ò����������� ���޸�����ʱ���뱣����ɿƼ��İ�Ȩ����������������
* 
* �ļ�����          main
* ��˾����          �ɶ���ɿƼ����޹�˾
* �汾��Ϣ          �鿴 libraries/doc �ļ����� version �ļ� �汾˵��
* ��������          IAR 8.32.4 or MDK 5.33
* ����ƽ̨          RT1064DVL6A
* ��������          https://seekfree.taobao.com/
* 
* �޸ļ�¼
* ����              ����                ��ע
* 2022-09-21        SeekFree            first version
********************************************************************************************************************/
#include "para_space.h"
// �������ǿ�Դ����ֲ�ÿչ���
/*      ÿ��һ�� �ù�ʡ��             ����ΰ� �ȹ�����        */
/* \\ \\ \\ \\ \\ \\ \\ || || || || || || // // // // // // // //
\\ \\ \\ \\ \\ \\ \\        _ooOoo_          // // // // // // //
\\ \\ \\ \\ \\ \\          o8888888o            // // // // // //
\\ \\ \\ \\ \\             88" . "88               // // // // //
\\ \\ \\ \\                (| -_- |)                  // // // //
\\ \\ \\                   O\  =  /O                     // // //
\\ \\                   ____/`---'\____                     // //
\\                    .'  \\|     |//  `.                      //
==                   /  \\|||  :  |||//  \                     ==
==                  /  _||||| -:- |||||-  \                    ==
==                  |   | \\\  -  /// |   |                    ==
==                  | \_|  ''\---/''  |   |                    ==
==                  \  .-\__  `-`  ___/-. /                    ==
==                ___`. .'  /--.--\  `. . ___                  ==
==              ."" '<  `.___\_<|>_/___.'  >'"".               ==
==            | | :  `- \`.;`\ _ /`;.`/ - ` : | |              \\
//            \  \ `-.   \_ __\ /__ _/   .-` /  /              \\
//      ========`-.____`-.___\_____/___.-`____.-'========      \\
//                           `=---='                           \\
// //   ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^  \\ \\
// // //      ���汣��      ����BUG      �����޸�          \\ \\ \\
// // // // // // || || || || || || || || || || \\ \\ \\ \\ \\ */

//
void process_image(void);
//
void find_corners(void);
//
void PIT_IRQHandler(void)
{
    if(pit_flag_get(PIT_CH3))
    {
      pit_flag_clear(PIT_CH3);
			get_encoder();
    }
}
//
int main(void)
{
    clock_init(SYSTEM_CLOCK_600M);  // ����ɾ��
    debug_init();                  // ���Զ˿ڳ�ʼ��
    // �˴���д�û����� ���������ʼ�������
		wireless_uart_init();
		timer_init(GPT_TIM_1, TIMER_MS);
		interrupt_set_priority(PIT_IRQn, 0);
		interrupt_global_enable(0);
		pit_ms_init(PIT_CH3,4);
		encoder_init();
	
	
		ips200_set_dir(IPS200_CROSSWISE_180);
		ips200_init(IPS200_TYPE_SPI);
	
		seekfree_assistant_interface_init(SEEKFREE_ASSISTANT_WIRELESS_UART);
	
		while(mt9v03x_init())
		{
			printf("camera Init error");
		}
    // �˴���д�û����� ���������ʼ�������
		
		ImagePerspective_Init();
		Motor_Init();
		//gear();
		imu963ra_init ();
		int cnt =0;

    while(1)
    {
			
			 if(mt9v03x_finish_flag)
        {
					  timer_start(GPT_TIM_1);
					  /* copy image from discere pointer inverse perspective mapping*/
					  IPMcopy();
						blur(&img_raw,&img_AP,7);
						dilate3(&img_raw,&img_AP);
						//draw_rec();
						process_image();
						find_corners();
					#if 0
						if(Lpt0_found==Lpt1_found == true)
						{
							draw_x(&img_raw,clip(rpts0s[Lpt0_rpts0s_id][0],0,113),clip(rpts0s[Lpt0_rpts0s_id][1],0,99),3,0);
							draw_x(&img_raw,clip(rpts1s[Lpt1_rpts1s_id][0],0,113),clip(rpts1s[Lpt1_rpts1s_id][1],0,99),3,0);
						}
					#endif
						/*******stop*****/
						
						if(ipts0_num==0&&ipts1_num==0)
						{
							cnt++;
							if(cnt>50)
							{
								for(uint16_t i=0;i<25600;i++)
								{
								mecanum_basic(0,0);
								}
								Motor_Init();
								return 0;
							}
						}
						else
						{
							cnt=0;
						}
						/******************/
						int16 zv=(leftfront+leftrear+rightfront+rightrear)/40;
						float oa=calculator(rpts[10]);
						float a=calculator(aim0)+calculator(aim1);
						if(calculator(aim0)+calculator(aim1)!=calculator(aim0)+calculator(aim1))break;
						float fa=fabs(a);
						aim0=rptsc0[16+zv];
						aim1=rptsc1[17+zv];
						
						check_cross();
						if(cross_type != CROSS_NONE)
						{
							run_cross();
							clear_image(&img_AP);
							draw_cross();
							draw();						
						}
						if(cross_type == CROSS_BEGIN||cross_type == CROSS_IN)
						{
						aim0=rptsc0[clip(16+zv,0,rpts0s_num)];
						aim1=rptsc1[clip(17+zv,0,rpts1s_num)];
						}
						if (cross_type != CROSS_IN) {
							if(cross_type ==CROSS_BEGIN)
							{v=80-112*fa;
								mecanum_basic(v,(1.2-fa)*PidLocCtrl(&angle,0,kalmanFilter(&KFP_height,-a)));}
							else
							{v=100-140*fa;
								mecanum_basic(v,(1.2-fa)*PidLocCtrl(&angle,0,kalmanFilter(&KFP_height,-a)));}
							

							
						} 
						else 
						{

							if (track_type == TRACK_LEFT) 
							{
                track_leftline(far_rpts0s + far_Lpt0_rpts0s_id, far_rpts0s_num - far_Lpt0_rpts0s_id, rpts,
                               (int) round(angle_dist / sample_dist), pixel_per_meter * ROAD_WIDTH / 2);
                rpts_num = far_rpts0s_num - far_Lpt0_rpts0s_id;
							} 
							else 
							{
                track_rightline(far_rpts1s + far_Lpt1_rpts1s_id, far_rpts1s_num - far_Lpt1_rpts1s_id, rpts,
                                (int) round(angle_dist / sample_dist), pixel_per_meter * ROAD_WIDTH / 2);
                rpts_num = far_rpts1s_num - far_Lpt1_rpts1s_id;
							}
							for(uint8_t i=0;i<rpts_num;i++)
							show0[clip(rpts[rpts_num-i][1],0,99)][clip(rpts[rpts_num-i][0],0,113)]=0;
							draw_o(&img_raw,clip(rpts[0][0],0,113),clip(rpts[0][1],0,99),4,0);
							mecanum_basic(80,-0.4*oa);
						}
						switch(cross_type)
						{
							case	CROSS_NONE:
								ips200_show_string(0,120,"CROSS_NONE");
								break;
							case	CROSS_IN:
								ips200_show_string(0,120,"CROSS_IN");
								break;
							case	CROSS_BEGIN:
								ips200_show_string(0,120,"CROSS_BEGIN");
								break;
							case	CROSS_NUM:
								ips200_show_string(0,120,"CROSS_NUM");
								break;
						}

						/*******Service for vofa****************/

						
						JF_Data.data[1] =0;
						JustFloat_Send();
						
						/***************************************/
						#if 0						
						v=100-140*fa;
						mecanum_basic(v,(1.25-fa)*PidLocCtrl(&angle,0,kalmanFilter(&KFP_height,-a)));
						#endif
					  //if(calculator(aim0)+calculator(aim1)==calculator(aim0)+calculator(aim1))
						//steer(calculator(aim0)+calculator(aim1));
						//frontspeed(20);
						//rearspeed(70);
						//forwheel(PidIncCtrl(&lr,leftrear,100));
						//front(calculator(aim0)+calculator(aim1));
						//ips200_show_gray_image(0,0, mt9v03x_image[0],USED_COL,USED_ROW,USED_COL,USED_ROW,0);
						//clear_image(&img_raw);
						//draw();		
						//draw_x(&img_raw,clip(rptsc1[23][0],0,113),clip(rptsc1[23][1],0,99),3,0);
						//draw_x(&img_raw,clip(rptsc0[23][0],0,113),clip(rptsc0[23][1],0,99),3,0);
						#if 0
						check_cross();
						if(cross_type != CROSS_NONE)
						{
							run_cross();
							clear_image(&img_AP);
							draw_cross();
							draw();						
						}
						#endif
						ips200_show_gray_image(0,0,show0[0],RESULT_COL,RESULT_ROW,RESULT_COL,RESULT_ROW,0);
						//ips200_show_gray_image(114,0,show1[0],RESULT_COL,RESULT_ROW,RESULT_COL,RESULT_ROW,0);
						timer_stop(GPT_TIM_1);
						//imu963ra_get_acc();
						//ips200_show_uint(1,1,imu963ra_acc_x,2);
						ips200_show_uint(200,200,timer_get(GPT_TIM_1),2);
						timer_clear(GPT_TIM_1);
						mt9v03x_finish_flag=0;		
					#if 0

						mt9v03x_finish_flag = 0;						
							// �ڷ���ǰ��ͼ�񱸷��ٽ��з��ͣ��������Ա���ͼ�����˺�ѵ�����
						memcpy(image_copy[0], show0[0], MT9V03X_IMAGE_SIZE);
						seekfree_assistant_camera_send();
						
					#endif
        }


        // �˴���д��Ҫѭ��ִ�еĴ���
    }
		return 0;
}


void process_image(void) {
		
    int x1 = img_raw.width / 2 - begin_x, y1 = begin_y;
    ipts0_num = sizeof(ipts0) / sizeof(ipts0[0]);
    for (; x1 > 0; x1--) if (AT_IMAGE(&img_raw, x1 - 1, y1) < thres) break;
    if (AT_IMAGE(&img_raw, x1, y1) >= thres)
        findline_lefthand_adaptive(&img_raw, block_size, clip_value, x1, y1-1, ipts0, &ipts0_num);
    else ipts0_num=0;
		
    int x2 = img_raw.width / 2 + begin_x, y2 = begin_y;
    ipts1_num = sizeof(ipts1) / sizeof(ipts1[0]);
    for (; x2 < img_raw.width - 1; x2++) if (AT_IMAGE(&img_raw, x2 + 1, y2) < thres) break;
    if (AT_IMAGE(&img_raw, x2, y2) >= thres)
        findline_righthand_adaptive(&img_raw, block_size, clip_value, x2, y2, ipts1, &ipts1_num);
    else ipts1_num=0;
		
		blur_points(ipts0, ipts0_num, rpts0b, (int) round(line_blur_kernel));
    rpts0b_num = ipts0_num;
    blur_points(ipts1, ipts1_num, rpts1b, (int) round(line_blur_kernel));
    rpts1b_num = ipts1_num;
		
		rpts0s_num = sizeof(rpts0s) / sizeof(rpts0s[0]);
    resample_points(rpts0b, rpts0b_num, rpts0s, &rpts0s_num, sample_dist * pixel_per_meter);
    rpts1s_num = sizeof(rpts1s) / sizeof(rpts1s[0]);
    resample_points(rpts1b, rpts1b_num, rpts1s, &rpts1s_num, sample_dist * pixel_per_meter);
		
		
		
    local_angle_points(rpts0s, rpts0s_num, rpts0a, (int) round(angle_dist / sample_dist));
    rpts0a_num = rpts0s_num;
    local_angle_points(rpts1s, rpts1s_num, rpts1a, (int) round(angle_dist / sample_dist));
    rpts1a_num = rpts1s_num;

    
    nms_angle(rpts0a, rpts0a_num, rpts0an, (int) round(angle_dist / sample_dist) * 2 + 1);
    rpts0an_num = rpts0a_num;
    nms_angle(rpts1a, rpts1a_num, rpts1an, (int) round(angle_dist / sample_dist) * 2 + 1);
    rpts1an_num = rpts1a_num;
		
		
		track_leftline(rpts0s, rpts0s_num, rptsc0, (int) round(angle_dist / sample_dist), pixel_per_meter * ROAD_WIDTH / 2);
    rptsc0_num = rpts0s_num;
    track_rightline(rpts1s, rpts1s_num, rptsc1, (int) round(angle_dist / sample_dist), pixel_per_meter * ROAD_WIDTH / 2);
    rptsc1_num = rpts1s_num;
		
}

void find_corners() {
		Lpt0_found = Lpt1_found = false;
    is_straight0 = rpts0s_num > 1. / sample_dist;
    is_straight1 = rpts1s_num > 1. / sample_dist;
    for (int i = 0; i < rpts0s_num; i++) {
        if (rpts0an[i] == 0) continue;
        int im1 = clip(i - (int) round(angle_dist / sample_dist), 0, rpts0s_num - 1);
        int ip1 = clip(i + (int) round(angle_dist / sample_dist), 0, rpts0s_num - 1);
        float conf = fabs(rpts0a[i]) - (fabs(rpts0a[im1]) + fabs(rpts0a[ip1])) / 2;

        //L-corner
        if (Lpt0_found == false && 70. / 180. * PI < conf && conf < 140. / 180. * PI && i < 0.4 / sample_dist) {
            Lpt0_rpts0s_id = i;
            Lpt0_found = true;
						JF_Data.data[2] = conf;
        }
        //straight road 
        if (conf > 5. / 180. * PI && i < 1.0 / sample_dist) is_straight0 = false;
        if (Lpt0_found == true && is_straight0 == false) break;
    }
    for (int i = 0; i < rpts1s_num; i++) {
        if (rpts1an[i] == 0) continue;
        int im1 = clip(i - (int) round(angle_dist / sample_dist), 0, rpts1s_num - 1);
        int ip1 = clip(i + (int) round(angle_dist / sample_dist), 0, rpts1s_num - 1);
        float conf = fabs(rpts1a[i]) - (fabs(rpts1a[im1]) + fabs(rpts1a[ip1])) / 2;
       
        if (Lpt1_found == false && 60. / 180. * PI < conf && conf < 140. / 180. * PI && i < 0.4 / sample_dist) {
            Lpt1_rpts1s_id = i;
            Lpt1_found = true;
						JF_Data.data[3] =conf;
        }

        if (conf > 5. / 180. * PI && i < 1.0 / sample_dist) is_straight1 = false;

        if (Lpt1_found == true && is_straight1 == false) break;
    }

    if (1) {
        if (Lpt0_found && Lpt1_found) {
            float dx = rpts0s[Lpt0_rpts0s_id][0] - rpts1s[Lpt1_rpts1s_id][0];
            float dy = rpts0s[Lpt0_rpts0s_id][1] - rpts1s[Lpt1_rpts1s_id][1];
            float dn = sqrtf(dx * dx + dy * dy);
						JF_Data.data[0] =fabs(dn - 0.45 * pixel_per_meter);
            if (fabs(dn - 0.45 * pixel_per_meter) < 0.15 * pixel_per_meter) {
                float dwx = rpts0s[clip(Lpt0_rpts0s_id + 50, 0, rpts0s_num - 1)][0] -
                            rpts1s[clip(Lpt1_rpts1s_id + 50, 0, rpts1s_num - 1)][0];
                float dwy = rpts0s[clip(Lpt0_rpts0s_id + 50, 0, rpts0s_num - 1)][1] -
                            rpts1s[clip(Lpt1_rpts1s_id + 50, 0, rpts1s_num - 1)][1];
                float dwn = sqrtf(dwx * dwx + dwy * dwy);
                if (!(dwn > 0.7 * pixel_per_meter &&
                      rpts0s[clip(Lpt0_rpts0s_id + 50, 0, rpts0s_num - 1)][0] < rpts0s[Lpt0_rpts0s_id][0] &&
                      rpts1s[clip(Lpt1_rpts1s_id + 50, 0, rpts1s_num - 1)][0] > rpts1s[Lpt1_rpts1s_id][0])) {
                    Lpt0_found = Lpt1_found = false;
                }
            } else {
                Lpt0_found = Lpt1_found = false;
            }
        }
    }
}
