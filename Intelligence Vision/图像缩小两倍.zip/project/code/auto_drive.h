#ifndef __AUTODRIVE_H__
#define	__AUTODRIVE_H__


void rearspeed(float speed);
void frontspeed(float speed);
void mecanum_basic(float y,float x,float w);
#endif