#ifndef __ENCODER__H__
#define __ENCODER__H__

void encoder_init(void);
void get_encoder(void);

#endif 
