#ifndef __PPERSIUT_H__
#define	__PPERSIUT_H__
float calculator(float * aim);
#endif