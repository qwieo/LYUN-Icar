#ifndef __MAIN_H__
#define	__MAIN_H__
#define ROAD_WIDTH      (0.45)
#include <math.h>
#endif